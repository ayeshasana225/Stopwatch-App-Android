package com.example.stopwatch;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {

    // UI elements
    private TextView timerTextView;
    private Button startButton, stopButton, resetButton;

    // Stopwatch variables
    private boolean isRunning = false;
    private int seconds = 0;

    // Handler and Runnable for updating the timer
    private final Handler handler = new Handler();
    private final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (isRunning) {
                seconds++;
                updateTimerText();
            }
            // Schedule the runnable to run again after 1000 milliseconds (1 second)
            handler.postDelayed(this, 1000);
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        timerTextView = findViewById(R.id.timerTextView);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        resetButton = findViewById(R.id.resetButton);

        // Set click listeners for buttons
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickStart();
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickStop();
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickReset();
            }
        });

        // Restore the state during configuration changes (e.g., device rotation)
        if (savedInstanceState != null) {
            isRunning = savedInstanceState.getBoolean("isRunning");
            seconds = savedInstanceState.getInt("seconds");
            updateTimerText();
            // Resume the timer if it was running before the configuration change
            if (isRunning) {
                handler.postDelayed(runnable, 1000);
            }
        }
    }

    // Save the state during configuration changes
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("isRunning", isRunning);
        outState.putInt("seconds", seconds);
    }

    // Called when the Start button is clicked
    private void onClickStart() {
        isRunning = true;
        // Start the timer by posting the runnable with a delay of 1000 milliseconds (1 second)
        handler.postDelayed(runnable, 1000);
    }

    // Called when the Stop button is clicked
    private void onClickStop() {
        isRunning = false;

        // Remove the runnable callbacks to stop the timer
        handler.removeCallbacks(runnable);
    }

    // Called when the Reset button is clicked
    private void onClickReset() {
        isRunning = false;
        seconds = 0;
        updateTimerText();

        // Remove the runnable callbacks to stop the timer
        handler.removeCallbacks(runnable);
    }

    // Update the timer display with minutes and seconds
    private void updateTimerText() {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        // Format the time as MM:SS
        String time = String.format("%02d:%02d", minutes, remainingSeconds);
        // Set the formatted time to the timerTextView
        timerTextView.setText(time);
    }
}
